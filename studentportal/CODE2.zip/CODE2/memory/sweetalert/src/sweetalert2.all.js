import styles from '../dist/sweetalert2.css'
import { injectCSS } from './utils/dom'
import sweetAlert from './sweetalert2'

injectCSS(styles)

export default sweetAlert
