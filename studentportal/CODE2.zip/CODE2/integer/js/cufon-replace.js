Cufon.replace('nav ul li, footer .fleft, #search-form a, h2, h3', { fontFamily: 'Myriad Pro Regular', hover:true });
Cufon.replace('#banner h2', { fontFamily: 'Myriad Pro Regular', textShadow:'1px 1px #0085c7' });
Cufon.replace('#banner h2 span', { fontFamily: 'Myriad Pro Light', textShadow:'1px 1px #0085c7' });