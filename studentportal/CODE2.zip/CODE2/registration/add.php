<?php
   include('../session.php');
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      $username = mysqli_real_escape_string($con,$_POST['username']);
      $reg = mysqli_real_escape_string($con,$_POST['reg']);
      $class = mysqli_real_escape_string($con,$_POST['class']);   
      $level1='0';   
      if($class=='5'||$class=='6')
        $level1='level0';
      if($class=='7'||$class=='8')
        $level1='level1';
      if($class=='9'||$class=='10')
        $level1='level2';
      if($class=='11'||$class=='12')
        $level1='level3';
       $sub=$level."_sub_ans";
       $sql="SELECT * FROM $sub WHERE reg='$reg'";
       $result=mysqli_query($con,$sql);
       $count=mysqli_num_rows($result);
       if($count>0)
          header("location: ../home.php");  
      if($level1=='level0'){
        $sub=$level."_sub_ans";
        $sql = "INSERT INTO $sub (username,reg,level) VALUES ('$username', '$reg', '$level1')";
        $result2 = mysqli_query($con,$sql);
        if (!($result2)){
          echo("Error description: " . mysqli_error($con));
        }
       else
         header("location: ../level0/sub.php");  
      }
    else{   
      $sql = "INSERT INTO pro_ans (username,reg,level) VALUES ('$username', '$reg', '$level1')";  
      $result1 = mysqli_query($con,$sql);
      $sub=$level."_sub_ans";
      $sql = "INSERT INTO $sub (username,reg,level) VALUES ('$username', '$reg', '$level1')";
      $result2 = mysqli_query($con,$sql);
      $sub=$level."_memory_ans";   
      $sql = "INSERT INTO $sub (username,reg,level) VALUES ('$username', '$reg', '$level1')";
      $result3 = mysqli_query($con,$sql);
      $sub=$level."_integer_ans";
      $sql = "INSERT INTO $sub (username,reg,level) VALUES ('$username', '$reg', '$level1')";
      $result4 = mysqli_query($con,$sql);   
        echo $sql;    
       if (!($result1 && $result2 && $result3 && $result4)){
          echo("Error description: " . mysqli_error($con));
       }
       else
         header("location: ../instructions.php");
    }
   }
?>
